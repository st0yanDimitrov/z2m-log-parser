# Zigbee2mqtt log parser

A simple log parser for zigbee2mqtt logs.